// Никакого бэкенда — приложение работает автономно.
// Все данные хранятся в SQLite на устройстве.
// Синхронизация идёт напрямую с moodle.preco.ru.

export const MOODLE_BASE_URL = "https://moodle.preco.ru";

export const TASK_TYPES = {
  homework: { label: "Домашнее задание", color: "#3b82f6" },
  deadline: { label: "Дедлайн", color: "#f97316" },
  exam: { label: "Экзамен", color: "#ef4444" },
  session: { label: "Сессия", color: "#8b5cf6" },
} as const;

export type TaskType = keyof typeof TASK_TYPES;
