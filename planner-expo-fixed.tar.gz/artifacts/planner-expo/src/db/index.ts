import * as SQLite from "expo-sqlite";

export interface Task {
  id: string;
  title: string;
  description: string | null;
  date: string;
  type: "exam" | "deadline" | "homework" | "session";
  subject: string;
  completed: boolean;
  notificationDays: number;
  source: "manual" | "moodle";
  createdAt: string;
}

export interface TaskStats {
  total: number;
  completed: number;
  upcoming: number;
  overdue: number;
}

// Called by SQLiteProvider on first open
export async function initDatabase(db: SQLite.SQLiteDatabase): Promise<void> {
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      date TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'homework',
      subject TEXT NOT NULL DEFAULT '',
      completed INTEGER NOT NULL DEFAULT 0,
      notification_days INTEGER NOT NULL DEFAULT 1,
      source TEXT NOT NULL DEFAULT 'manual',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS moodle_cache (
      key TEXT PRIMARY KEY NOT NULL,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);
}

// ── Tasks ────────────────────────────────────────────────────────────────────

function rowToTask(row: any): Task {
  return {
    id: row.id,
    title: row.title,
    description: row.description ?? null,
    date: row.date,
    type: row.type,
    subject: row.subject,
    completed: row.completed === 1,
    notificationDays: row.notification_days,
    source: row.source,
    createdAt: row.created_at,
  };
}

export function getAllTasks(db: SQLite.SQLiteDatabase): Task[] {
  const rows = db.getAllSync<any>(
    "SELECT * FROM tasks ORDER BY date ASC"
  );
  return rows.map(rowToTask);
}

export function getTaskStats(db: SQLite.SQLiteDatabase): TaskStats {
  const now = new Date().toISOString();
  const all = db.getAllSync<any>("SELECT completed, date FROM tasks");
  const total = all.length;
  const completed = all.filter((r) => r.completed === 1).length;
  const upcoming = all.filter(
    (r) => r.completed === 0 && r.date >= now
  ).length;
  const overdue = all.filter(
    (r) => r.completed === 0 && r.date < now
  ).length;
  return { total, completed, upcoming, overdue };
}

export function createTask(
  db: SQLite.SQLiteDatabase,
  data: Omit<Task, "id" | "createdAt">
): Task {
  const id = `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const createdAt = new Date().toISOString();
  db.runSync(
    `INSERT INTO tasks (id, title, description, date, type, subject, completed, notification_days, source, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      data.title,
      data.description ?? null,
      data.date,
      data.type,
      data.subject,
      data.completed ? 1 : 0,
      data.notificationDays,
      data.source,
      createdAt,
    ]
  );
  return { ...data, id, createdAt };
}

export function updateTask(
  db: SQLite.SQLiteDatabase,
  id: string,
  patch: Partial<Pick<Task, "completed" | "title" | "date" | "type" | "subject">>
): void {
  const sets: string[] = [];
  const vals: any[] = [];
  if (patch.completed !== undefined) {
    sets.push("completed = ?");
    vals.push(patch.completed ? 1 : 0);
  }
  if (patch.title !== undefined) {
    sets.push("title = ?");
    vals.push(patch.title);
  }
  if (patch.date !== undefined) {
    sets.push("date = ?");
    vals.push(patch.date);
  }
  if (patch.type !== undefined) {
    sets.push("type = ?");
    vals.push(patch.type);
  }
  if (patch.subject !== undefined) {
    sets.push("subject = ?");
    vals.push(patch.subject);
  }
  if (sets.length === 0) return;
  vals.push(id);
  db.runSync(`UPDATE tasks SET ${sets.join(", ")} WHERE id = ?`, vals);
}

export function deleteTask(db: SQLite.SQLiteDatabase, id: string): void {
  db.runSync("DELETE FROM tasks WHERE id = ?", [id]);
}

export function upsertMoodleTasks(
  db: SQLite.SQLiteDatabase,
  tasks: Task[]
): void {
  // Delete old moodle tasks, then insert fresh ones
  db.runSync("DELETE FROM tasks WHERE source = 'moodle'");
  for (const t of tasks) {
    db.runSync(
      `INSERT OR REPLACE INTO tasks
         (id, title, description, date, type, subject, completed, notification_days, source, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'moodle', ?)`,
      [
        t.id,
        t.title,
        t.description ?? null,
        t.date,
        t.type,
        t.subject,
        0,
        t.notificationDays,
        t.createdAt,
      ]
    );
  }
}

// ── Moodle cache ─────────────────────────────────────────────────────────────

export function getMoodleCache(
  db: SQLite.SQLiteDatabase,
  key: string
): string | null {
  const row = db.getFirstSync<{ value: string }>(
    "SELECT value FROM moodle_cache WHERE key = ?",
    [key]
  );
  return row?.value ?? null;
}

export function setMoodleCache(
  db: SQLite.SQLiteDatabase,
  key: string,
  value: string
): void {
  db.runSync(
    `INSERT OR REPLACE INTO moodle_cache (key, value, updated_at) VALUES (?, ?, ?)`,
    [key, value, new Date().toISOString()]
  );
}
