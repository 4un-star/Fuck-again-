import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import * as SecureStore from "expo-secure-store";
import { validateMoodleLogin } from "@/api/moodle";

const USERNAME_KEY = "moodle_username";
const PASSWORD_KEY = "moodle_password";

interface AuthState {
  username: string;
  password: string;
}

interface AuthContextValue {
  user: AuthState | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthState | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Проверяем сохранённые учётные данные при старте
  useEffect(() => {
    (async () => {
      try {
        const username = await SecureStore.getItemAsync(USERNAME_KEY);
        const password = await SecureStore.getItemAsync(PASSWORD_KEY);
        if (username && password) {
          // Доверяем сохранённым данным — не перепроверяем при каждом запуске
          // (приложение работает оффлайн, проверка при синхронизации)
          setUser({ username, password });
        }
      } catch {
        // Если SecureStore недоступен — работаем без авторизации
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    // Проверяем учётные данные через Moodle
    const valid = await validateMoodleLogin(username, password);
    if (!valid) {
      throw new Error("Неверный логин или пароль");
    }
    // Сохраняем в защищённом хранилище на телефоне
    await SecureStore.setItemAsync(USERNAME_KEY, username);
    await SecureStore.setItemAsync(PASSWORD_KEY, password);
    setUser({ username, password });
  }, []);

  const logout = useCallback(async () => {
    await SecureStore.deleteItemAsync(USERNAME_KEY);
    await SecureStore.deleteItemAsync(PASSWORD_KEY);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
}
